from flask import Flask, render_template, request
import os

app = Flask(__name__)


@app.route("/")
def mission():
    return "Миссия Колонизация Марса"


@app.route('/load_photo', methods=['GET', 'POST'])
def load_photo():
    if request.method == 'POST':
        photo = request.files['photo']
        photo.save(os.path.join('static/uploads', "upload.jpg"))
    return render_template('load_photo.html')


@app.route('/astronaut_selection', methods=['GET', 'POST'])
def selection_results():
    return render_template('astronaut_selection.html')


@app.route('/choice/<planet_name>')
def show_planet(planet_name):
    return render_template(f'{planet_name}.html')


@app.route('/results/<nickname>/<int:level>/<float:rating>')
def results(nickname, level, rating):
    return render_template('results.html', nickname=nickname, level=level, rating=rating)


if __name__ == '__main__':
    app.run(port=8080)
