from flask import Flask, render_template, url_for, request

app = Flask(__name__)


@app.route("/")
def mission():
    return "Миссия Колонизация Марса"


@app.route('/astronaut_selection', methods=['GET', 'POST'])
def selection_results():
    return render_template('astronaut_selection.html')


@app.route('/choice/<planet_name>')
def show_planet(planet_name):
    return render_template(f'{planet_name}.html')


@app.route('/results/<nickname>/<int:level>/<float:rating>')
def results(nickname, level, rating):
    return render_template('results.html', nickname=nickname, level=level, rating=rating)


if __name__ == '__main__':
    app.run(port=8080)
