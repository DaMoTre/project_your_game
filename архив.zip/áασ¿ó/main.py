from flask import Flask, render_template, url_for, request

app = Flask(__name__)


@app.route("/")
def mission():
    return "Миссия Колонизация Марса"


@app.route('/choice/<planet_name>')
def show_planet(planet_name):
    return render_template(f'{planet_name}.html')


if __name__ == '__main__':
    app.run(port=8080)
