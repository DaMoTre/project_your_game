import openai
openai.api_key = "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"

messages = [
 {"role": "system", "content": "I write you the name of the category, and you come up with 5 answers and 5 questions "
                               "for this category for \"your game\", that is, the first question should be "
                               "the simplest, the fifth the most difficult.\n"
                               "Give the answers only in the format:\n"
                               "Question 1: ...\n"
                               "Question 2: ...\n"
                               "Question 3: ...\n"
                               "Question 4: ...\n"
                               "Question 5: ...\n"
                               "Answer 1: ...\n"
                               "Answer 2: ...\n"
                               "Answer 3: ...\n"
                               "Answer 4: ...\n"
                               "Answer 5: ..."}
]

content = input("User: ")
messages.append({"role": "user", "content": content})

completion = openai.ChatCompletion.create(
  model="gpt-3.5-turbo",
  messages=messages
)


def rebild_sistem(data):
    if data != "":
        return data.split(": ")[-1]
    else:
        return False


chat_response = list(map(rebild_sistem, completion.choices[0].message.content.split("\n")))
mass = [[chat_response[i], chat_response[i + 6], False] for i in range(5)]
print(f"ChatGPT: {mass}")
